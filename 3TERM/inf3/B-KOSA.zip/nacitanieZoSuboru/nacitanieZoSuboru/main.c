#include <stdio.h>
#include <stdlib.h>


void naplneniePolaRandom(int* pole, int Int) {
    pole[0] = rand() % Int;
    pole[1] = rand() % Int;
    pole[2] = rand() % Int;
}

int najdiMaxmimum(int* subor, int* randomIndex) {
    int max = subor[randomIndex[0]];

    if (max < subor[randomIndex[1]])
        max = subor[randomIndex[1]];

    if (max < subor[randomIndex[2]])
        max = subor[randomIndex[2]];

    return max;
}

void vypisVystup(int* subor, int* randomIndex, int Int, int max) {
    printf("Vstup: ");
    for (int i = 0; i < Int; i++) {
        printf("%d ", subor[i]);
    }
    printf("\n");

    printf("Generovane indexy: ");
    for (int i = 0; i < 3; i++) {
        printf("%d ", randomIndex[i]);
    }
    printf("\n");

    printf("Najvacisie cislo je: %d\n", max);
}


int main(int argc, const char* argv[]) {
    if (argc == 1) {
        printf("Chybny pocet argumentov");
        return 1;
    }

    srand(time(NULL));

    //ziskanie nazvu suboru z arguemtnu
    char* nazovSuboru = argv[1];

    FILE* subor = fopen(nazovSuboru, "r");
    const int DLZKA = 255;
    char riadok[255];

    if (subor == NULL) {
        printf("Chyba pri otvarani suboru");
        return 1;
    }

    //prevod stringu na int
    int Int = atoi(fgets(riadok, DLZKA, subor));

    // pole random cisel
    int* randCislo = (int*)malloc(3 * sizeof(int));
    if (randCislo == NULL) {
        printf("Chyba pri alokovani pamate");
        return 1;
    }
    naplneniePolaRandom(randCislo, Int);

    // pole na ulozenie suboru
    int* pole = (int*)malloc(Int * sizeof(int));
    if (pole == NULL) {
        printf("Chyba pri alokovani pamate"); 
        return 1;
    }

    // citanie suboru
    for (int i = 0; i < Int; i++) {
        fgets(riadok, DLZKA, subor);
        //vlozenie riadku do pola ako integer
        pole[i] = atoi(riadok);
    }

    int max = najdiMaxmimum(pole, randCislo);

    vypisVystup(pole, randCislo, Int, max);
    
    //uvolnenie pamate
    free(pole);
    free(randCislo);
    fclose(subor);
}